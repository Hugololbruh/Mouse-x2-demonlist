# My GD List

This is a super simple Geometry Dash level-list website.

To change the levels, open `index.html` and find `const levels = [...]`.

You can change:
- name
- creator
- difficulty
- image

The site works as a single file, so there are no CSS/JS folder 404 problems.
